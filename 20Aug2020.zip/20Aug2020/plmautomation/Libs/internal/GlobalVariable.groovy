package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.main.TestCaseMain


/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p></p>
     */
    public static Object OD_Test_URL
     
    /**
     * <p></p>
     */
    public static Object UserMainComp
     
    /**
     * <p></p>
     */
    public static Object PassMainComp
     
    /**
     * <p></p>
     */
    public static Object CompMain
     
    /**
     * <p></p>
     */
    public static Object varAlertCopyMessage
     
    /**
     * <p></p>
     */
    public static Object winIndexZeroTitle
     
    /**
     * <p></p>
     */
    public static Object varColorDuplicateMessage
     
    /**
     * <p></p>
     */
    public static Object UniqueValue
     
    /**
     * <p></p>
     */
    public static Object FilesPath
     
    /**
     * <p></p>
     */
    public static Object HardCodeUV
     
    /**
     * <p></p>
     */
    public static Object createStyles
     
    /**
     * <p></p>
     */
    public static Object createFabrics
     
    /**
     * <p></p>
     */
    public static Object createTrims
     
    /**
     * <p></p>
     */
    public static Object createMiscellaneous
     
    /**
     * <p></p>
     */
    public static Object articleCounter
     
    /**
     * <p></p>
     */
    public static Object colorCounter
     
    /**
     * <p></p>
     */
    public static Object delayAfterZeroFrame
     
    /**
     * <p></p>
     */
    public static Object createAllTP
     
    /**
     * <p></p>
     */
    public static Object qcCounter
     
    /**
     * <p></p>
     */
    public static Object articleOpenCategory
     
    /**
     * <p></p>
     */
    public static Object articleOpenCode
     
    /**
     * <p></p>
     */
    public static Object delay2seconds
     

    static {
        try {
            def selectedVariables = TestCaseMain.getGlobalVariables("default")
			selectedVariables += TestCaseMain.getGlobalVariables(RunConfiguration.getExecutionProfile())
            selectedVariables += RunConfiguration.getOverridingParameters()
    
            OD_Test_URL = selectedVariables['OD_Test_URL']
            UserMainComp = selectedVariables['UserMainComp']
            PassMainComp = selectedVariables['PassMainComp']
            CompMain = selectedVariables['CompMain']
            varAlertCopyMessage = selectedVariables['varAlertCopyMessage']
            winIndexZeroTitle = selectedVariables['winIndexZeroTitle']
            varColorDuplicateMessage = selectedVariables['varColorDuplicateMessage']
            UniqueValue = selectedVariables['UniqueValue']
            FilesPath = selectedVariables['FilesPath']
            HardCodeUV = selectedVariables['HardCodeUV']
            createStyles = selectedVariables['createStyles']
            createFabrics = selectedVariables['createFabrics']
            createTrims = selectedVariables['createTrims']
            createMiscellaneous = selectedVariables['createMiscellaneous']
            articleCounter = selectedVariables['articleCounter']
            colorCounter = selectedVariables['colorCounter']
            delayAfterZeroFrame = selectedVariables['delayAfterZeroFrame']
            createAllTP = selectedVariables['createAllTP']
            qcCounter = selectedVariables['qcCounter']
            articleOpenCategory = selectedVariables['articleOpenCategory']
            articleOpenCode = selectedVariables['articleOpenCode']
            delay2seconds = selectedVariables['delay2seconds']
            
        } catch (Exception e) {
            TestCaseMain.logGlobalVariableError(e)
        }
    }
}
