<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>mandatoryDeliveryStartDate</name>
   <tag></tag>
   <elementGuidId>e3a3e6f4-1d04-4848-87bd-ae86166b8aea</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@type = 'checkbox' and @name = 'chkDeliveryStartDateMandatory']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//input[@name='chkDeliveryStartDateMandatory']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
