<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>selectType</name>
   <tag></tag>
   <elementGuidId>c3b5bf7e-2983-4ec6-8142-72312455b596</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@name = 'cboAttributeType' and @id = 'cboAttributeType' and (text() = 'TextText AreaDrop Down ListDateCheckbox' or . = 'TextText AreaDrop Down ListDateCheckbox')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='cboAttributeType']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
