<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>internalDeliveryTerms</name>
   <tag></tag>
   <elementGuidId>47c464d0-b5fd-41f3-8c3f-c6519bdac681</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@type = 'checkbox' and @name = 'chkDeliveryTermsReadOnly']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//input[@name='chkDeliveryTermsReadOnly']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
