<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>selectvValidation</name>
   <tag></tag>
   <elementGuidId>aaff8169-459f-4b6f-97c7-d565c5e5c79e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@name = 'cboValidations' and @id = 'cboValidations' and (text() = '[Select]NumericAlpha Numeric' or . = '[Select]NumericAlpha Numeric')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='cboValidations']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
