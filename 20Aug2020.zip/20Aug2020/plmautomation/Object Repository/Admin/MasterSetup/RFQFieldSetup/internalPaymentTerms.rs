<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>internalPaymentTerms</name>
   <tag></tag>
   <elementGuidId>570cdf34-6b9d-49f6-85af-fb95a943b646</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@type = 'checkbox' and @name = 'chkPaymentTermsReadOnly']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//input[@name='chkPaymentTermsReadOnly']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
