<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>selectCategory</name>
   <tag></tag>
   <elementGuidId>78d7e980-f646-4a25-817a-618337c42b28</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@name = 'cbtProductCat' and (text() = '[Select] Styles Fabrics Trims Miscellaneous' or . = '[Select] Styles Fabrics Trims Miscellaneous')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@name='cbtProductCat']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
