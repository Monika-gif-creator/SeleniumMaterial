<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>externalDeliveryTerms</name>
   <tag></tag>
   <elementGuidId>c484f20c-18df-4c06-98e1-7fc2d60a485f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@type = 'checkbox' and @name = 'chkDeliveryTermsPrint']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//input[@name='chkDeliveryTermsPrint']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
