<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>menuCompanySetup</name>
   <tag></tag>
   <elementGuidId>77ba4b24-f723-4d9d-a484-530fd0a3ae09</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@title = 'Company Setup' and @href = '../wfx/wfx_BaseSetting.aspx?MenuName=mnuCompanySetup&amp;RedirURL=wfx_MyCompanySite.aspx?CurrentTab=4' and (text() = 'Company Setup' or . = 'Company Setup')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li[@menuname='mnuCompanySetup']/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
