<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>checkBoxMandatory</name>
   <tag></tag>
   <elementGuidId>19e56c8d-8b46-4006-a709-fc7385aabcc0</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@type = 'checkbox' and @name = 'chkMandatory' and @id = 'chkMandatory']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//input[@id='chkMandatory']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
