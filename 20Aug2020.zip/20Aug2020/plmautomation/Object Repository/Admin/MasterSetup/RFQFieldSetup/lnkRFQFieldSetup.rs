<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lnkRFQFieldSetup</name>
   <tag></tag>
   <elementGuidId>cc46c208-9111-4b1a-8aff-9ac52554881d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[(text() = 'RFQ Field Setup' or . = 'RFQ Field Setup')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[text()='RFQ Field Setup']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
