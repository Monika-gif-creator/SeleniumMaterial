<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>mandatoryShipmentTerms</name>
   <tag></tag>
   <elementGuidId>35320c15-a850-4e65-b811-12005e90a6c4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@type = 'checkbox' and @name = 'chkShipmentTermsMandatory']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//input[@name='chkShipmentTermsMandatory']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
