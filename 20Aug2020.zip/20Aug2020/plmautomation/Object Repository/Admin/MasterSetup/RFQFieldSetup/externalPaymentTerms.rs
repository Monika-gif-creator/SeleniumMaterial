<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>externalPaymentTerms</name>
   <tag></tag>
   <elementGuidId>40610cc7-747e-4907-bfb4-c93706a6e2a2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@type = 'checkbox' and @name = 'chkPaymentTermsPrint']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//input[@name='chkPaymentTermsPrint']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
