<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>internalDeliveryStartDate</name>
   <tag></tag>
   <elementGuidId>a583f68c-f05f-4000-bbd2-57bbaf464977</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@type = 'checkbox' and @name = 'chkDeliveryStartDateReadOnly']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//input[@name='chkDeliveryStartDateReadOnly']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
