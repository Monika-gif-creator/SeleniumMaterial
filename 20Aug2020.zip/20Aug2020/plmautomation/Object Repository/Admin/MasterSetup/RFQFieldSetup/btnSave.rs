<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btnSave</name>
   <tag></tag>
   <elementGuidId>f6e642d1-c700-4db8-85aa-561650037b4f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'XLBL_144_1' and @title = 'Save the current record' and (text() = 'Save' or . = 'Save')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//span[@title='Save the current record']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
