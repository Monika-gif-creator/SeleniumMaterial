<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>externalShipmentTerms</name>
   <tag></tag>
   <elementGuidId>52d11cda-84bf-4c94-98d8-e4aeacd4f08c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@type = 'checkbox' and @name = 'chkShipmentTermsPrint']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//input[@name='chkShipmentTermsPrint']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
