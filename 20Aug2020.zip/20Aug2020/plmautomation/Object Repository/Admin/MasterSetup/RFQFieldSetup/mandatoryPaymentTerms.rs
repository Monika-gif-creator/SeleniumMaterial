<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>mandatoryPaymentTerms</name>
   <tag></tag>
   <elementGuidId>1b4f75ab-18a9-49ca-919f-e7dad0f64742</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@type = 'checkbox' and @name = 'chkPaymentTermsMandatory']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//input[@name='chkPaymentTermsMandatory']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
