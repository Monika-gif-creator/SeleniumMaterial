<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>linkDrowdownOptions</name>
   <tag></tag>
   <elementGuidId>09d178b5-5c93-4390-8a87-6975e2959a5a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//td[@class='clsCenterAlign']//a[@class='clsPageToolButton ToolLink'][contains(text(),'»')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
