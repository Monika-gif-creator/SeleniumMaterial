<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>linkMultiSelectoption</name>
   <tag></tag>
   <elementGuidId>19f7444e-c0a7-4d7c-9c4b-8bd495632744</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//td[@class='clsCenterAlign']//a[@class='clsPageToolButton ToolLink'][contains(text(),'»')])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
