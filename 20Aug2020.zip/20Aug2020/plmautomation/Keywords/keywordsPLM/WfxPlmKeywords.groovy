package keywordsPLM
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import org.openqa.selenium.Keys as Keys

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriverException;

import com.kms.katalon.core.testdata.TestData as TestData

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.exception.StepFailedException
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords

import com.kms.katalon.core.webui.common.WebUiCommonHelper as WebUiCommonHelper

import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement as WebElement

import internal.GlobalVariable
import WSBuiltInKeywords as WS
import WebUiBuiltInKeywords as WebUI


import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory
import com.kms.katalon.core.webui.driver.DriverFactory

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObjectProperty

import com.kms.katalon.core.mobile.helper.MobileElementCommonHelper
import com.kms.katalon.core.util.KeywordUtil

import com.kms.katalon.core.webui.exception.WebElementNotFoundException

import java.awt.Robot
import java.awt.Toolkit
import java.awt.datatransfer.StringSelection
import java.awt.event.KeyEvent
import org.openqa.selenium.By as By

import java.util.List;
import java.io.File

import java.util.Properties

import java.util.HashMap


class WfxPlmKeywords {

	@Keyword
	def uploadFile(String fileName,String fileType) {
		String filePath=''

		if(fileType.equalsIgnoreCase('Image')){
			filePath=GlobalVariable.FilesPath+'\\IMAGE\\'
		}else if(fileType.equalsIgnoreCase('pdf')){
			filePath=GlobalVariable.FilesPath+'\\PDF\\'
		}else if(fileType.equalsIgnoreCase('excel')){
			filePath=GlobalVariable.FilesPath+'\\EXCEL\\'
		}

		StringSelection sSelection = new StringSelection(new File(filePath+ fileName).getAbsolutePath());
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(sSelection, null);
		WebUI.delay(1)
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);

		robot.keyPress(KeyEvent.VK_CONTROL);
		robot.keyPress(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_V);
		robot.keyRelease(KeyEvent.VK_CONTROL);

		WebUI.delay(2)
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
	}

	@Keyword
	def clickOnMenu(TestObject testObject) {
		WebElement element = WebUiCommonHelper.findWebElement(testObject, 30)
		WebUI.executeJavaScript('arguments[0].click()', Arrays.asList(element))
	}

	@Keyword
	def clearTextBox(TestObject testObject) {
		WebUI.sendKeys(testObject, Keys.chord(Keys.CONTROL, 'a'))
		WebUI.sendKeys(testObject, Keys.chord(Keys.BACK_SPACE))
	}

	@Keyword
	def closeAllWindowsExceptRoot(WebDriver driver) {

		WebUI.switchToWindowTitle(GlobalVariable.winIndexZeroTitle)

		String currWindow=driver.getWindowHandle()

		Set<String> allOpenWindows=driver.getWindowHandles()

		for (eachWin in allOpenWindows) {
			if(!eachWin.contentEquals(currWindow)){
				driver.switchTo().window(eachWin)
				driver.close()
			}
		}
		WebUI.switchToWindowTitle(GlobalVariable.winIndexZeroTitle)
	}

	@Keyword
	def folderHandling(String folderName) {

		//		KeywordUtil.logInfo("Processing Folder Handling...")

		WebDriver browser = DriverFactory.getWebDriver()

		TestObject testObject=new TestObject('objectName')

		String masterNodeImg='//span[text()=\'MASTER\']//parent::div/img[contains(@src,\'treePlus\')]'

		testObject.addProperty("xpath",ConditionType.EQUALS, masterNodeImg)

		if(WebUI.waitForElementClickable(testObject, 5,FailureHandling.CONTINUE_ON_FAILURE)){
			WebUI.click(testObject)
		}

		WebUI.delay(5)

		String folder='//span[contains(text(),"'+folderName+'") ] [contains(@class,\'FolderNode\')]'
		testObject.addProperty("xpath",ConditionType.EQUALS, folder)

		def selectedNode = 'clsTreeSelectedNode'
		def classOnFolder=''

		def boolean folderExistsFlag=false

		List<WebElement> elements = WebUiBuiltInKeywords.findWebElements(testObject, 10)
		if(elements.size()>0){
			classOnFolder = WebUI.getAttribute((testObject), 'class')
			folderExistsFlag=true
		}

		if(!classOnFolder.contains(selectedNode)){

			if(folderExistsFlag){
				WebUI.click(findTestObject('zKeywordsObjects/MasterNode'))
				WebUI.delay(1)

				String treeIcon='//span[text()="'+folderName+'"]/preceding-sibling::img[2]'

				testObject.addProperty("xpath",ConditionType.EQUALS, treeIcon)

				List<WebElement> elements1 = WebUiBuiltInKeywords.findWebElements(testObject, 5)


				if(elements1.size()>0){

					WebUI.click(testObject,FailureHandling.CONTINUE_ON_FAILURE)
				}

				WebUI.delay(1)

				testObject.addProperty("xpath",ConditionType.EQUALS, folder)
				WebUI.click(testObject)
			}else{
				WebUI.click(findTestObject('zKeywordsObjects/MasterNode'))
				WebUI.delay(1)

				WebUI.click(findTestObject('zKeywordsObjects/btnAddFolder'))

				WebUI.delay(1)

				WebUI.switchToWindowIndex(1)
				WebUI.setText(findTestObject('zKeywordsObjects/inputFolderName'), folderName)
				WebUI.click(findTestObject('zKeywordsObjects/btnSaveAndClose'))
				WebUI.switchToWindowTitle(GlobalVariable.winIndexZeroTitle)
			}
		}
		//		KeywordUtil.markPassed("Folder Handling completed")
	}

	@Keyword
	def groupHandling(String folderName,String groupName ) {

		//		KeywordUtil.logInfo("Processing Folder Handling...")

		WebDriver browser = DriverFactory.getWebDriver()

		TestObject testObject=new TestObject('objectName')
		String groupN='//span[text()="'+folderName+'"]/parent::div/following::*[starts-with(text(),"'+groupName+'")]'
		testObject.addProperty("xpath",ConditionType.EQUALS, groupN)

		def selectedNode = 'clsTreeSelectedNode'
		def classOnGroup=''

		def boolean groupExistsFlag=false

		try{

			List<WebElement> elements = WebUiBuiltInKeywords.findWebElements(testObject, 5)
			if(elements.size()>0){

				classOnGroup = WebUI.getAttribute((testObject), 'class')
				groupExistsFlag=true
			}

			if(!classOnGroup.contains(selectedNode)){

				if(groupExistsFlag){

					testObject.addProperty("xpath",ConditionType.EQUALS, groupN)
					WebUI.click(testObject)
				}else{
					WebUI.click(findTestObject('zKeywordsObjects/btnAddGroup'))
					WebUI.delay(1)

					WebUI.switchToWindowIndex(1)
					WebUI.setText(findTestObject('zKeywordsObjects/inputGroupName'), groupName)
					WebUI.click(findTestObject('zKeywordsObjects/btnSaveAndClose'))
					WebUI.switchToWindowTitle(GlobalVariable.winIndexZeroTitle)
				}
			}
		}catch(Exception ex) {
			println 'Group keyword executed...'
		}
	}


	@Keyword
	def int getTypeOfColumnData(TestData data, String colName) {

		//Below commented code will be use in TestCase to handle folder structure
		/*
		 int folderTypes = CustomKeywords.'keywordsPLM.WfxPlmKeywords.getTypeOfColumnData'(dataSource, 'ColumnName')		
		 int groupTypes = CustomKeywords.'keywordsPLM.WfxPlmKeywords.getTypeOfColumnData'(dataSource, 'ColumnName')		
		 boolean isMultiple = true */

		Set<String> setFolders = new HashSet<String>();
		for(int i=1;i<=data.getRowNumbers();i++){
			setFolders.add(data.getValue(colName, i))
		}
		return setFolders.size()
	}

	@Keyword
	def setValueInPropertiesFile(String key,String value) {

		FileReader reader=new FileReader(new File('.\\CustomConfigurationFile\\tempFileForValuePassing.properties'));

		HashMap<String, String> configMap=new HashMap<String, String>()
		Properties prop=new Properties()

		prop.load(reader)

		for (String eachkey : prop.keySet()) {
			configMap.put(eachkey,prop.getProperty(eachkey))
		}

		String newKey=key.toLowerCase()

		configMap.put(newKey,value)

		OutputStream outputFile=new FileOutputStream(new File('.\\CustomConfigurationFile\\tempFileForValuePassing.properties'));

		for (String eachkey : configMap.keySet()) {
			prop.setProperty(eachkey, configMap.get(eachkey))
		}

		prop.store(outputFile, null)
		outputFile.close()
	}

	@Keyword
	def String getValueFromPropertiesFile(String key) {
		try{
			FileReader reader=new FileReader(new File('.\\CustomConfigurationFile\\tempFileForValuePassing.properties'));
			Properties prop=new Properties()
			prop.load(reader)
			String newKey=key.toLowerCase()
			return 	prop.getProperty(newKey).toString()
		}
		catch(Exception ex)
		{
			println ex.printStackTrace()
		}
	}

	@Keyword
	def setDataInReadOnlyCalander(TestObject testObject, String dt) {

		WebElement dateElement = WebUiCommonHelper.findWebElement(testObject, 30)
		WebUI.executeJavaScript('arguments[0].readOnly=false;', Arrays.asList(dateElement))
		WebUI.setText(testObject, dt)
		WebUI.executeJavaScript('arguments[0].readOnly=true;', Arrays.asList(dateElement))

	}
}
